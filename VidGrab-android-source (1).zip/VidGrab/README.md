# VidGrab — YouTube / Video Downloader (Android, Java)

A standalone Android app that:
- Receives shared URLs from **YouTube's share sheet** ("Share to → Save with VidGrab")
- Shows a bottom-sheet picker for **MP4 video quality** and **MP3 audio** (Fast, Classic MP3 70K/128K/320K, 144p/240p/360p/720p/1080p)
- Downloads into `Downloads/VidGrab/` using yt-dlp + ffmpeg wrapped for Android
- Plays downloaded videos using **ExoPlayer (media3)** and downloaded MP3s with a built-in **MP3 player + seekbar + prev/next/playlist**
- Stores a history of downloads in a local SQLite DB
- Has Snaptube-style Search / YouTube / Music / More tabs and a Settings page

## Build the APK for free from your phone

> Phone se APK banayi hai GitHub Actions pe — **Android Studio ki zaroorat nahi**.

1. App ki ZIP khole — saari files same structure me rahegi.
2. `https://github.com` pe login karo, **+** → **New repository** → name: `VidGrab`
3. **Add file → Upload files** → ZIP me se saari files exact structure me drag karo:
   ```
   .github/workflows/build.yml
   app/
   build.gradle
   settings.gradle
   gradle.properties
   gradle/wrapper/gradle-wrapper.properties
   ```
   (*Important:* `settings.gradle`, `build.gradle` repo ke ROOT me hone chahiye, `app/` ke andar nahi.)
4. **Commit changes** press karo.
5. Repository me **Actions** tab khole → green **build-debug-apk** job dikhegi → kuchh minute chhode.
6. Job complete hone par **build-debug-apk** pe click karo → neeche **Artifacts → VidGrab-debug** pe click karo.
7. ZIP hoke `app-debug.apk` download ho jayegi.
8. Phone me bhejo aur install karo. (Phone me **Install unknown apps** permission On karna padega.)

Baar baar `git push` karoge to APK har baar automatically re-build ho jayegi.

## YouTube share-sheet integration

YouTube video dekhne ke baad → **Share** button → list me **Save with VidGrab** dikhega → tap karo →
MP3 / MP4 quality picker open hoga → format select karo → **Start download** dabba → progress notification se download complete.

## Notes

- The download engine is [`io.github.junkfood02.youtubedl-android` 0.18.1](https://github.com/yausername/youtubedl-android) which bundles yt-dlp + ffmpeg for Android (Maven Central, ~small APK overhead).
- Min SDK 23 (Android 6), Target SDK 34 (Android 14).
- No bundling with Google Play services is required; the APK works fully offline once installed.
- I cannot compile or run the APK in this chat. Build steps above are the only path I support from here.
