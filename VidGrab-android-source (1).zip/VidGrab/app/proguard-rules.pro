# Keep youtubedl-android native bridges
-keep class com.yausername.youtubedl.** { *; }
-dontwarn com.yausername.youtubedl.**
