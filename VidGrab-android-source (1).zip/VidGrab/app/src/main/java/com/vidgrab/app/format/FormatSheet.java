package com.vidgrab.app.format;

import android.app.DownloadManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.vidgrab.app.R;
import com.vidgrab.app.download.DownloadService;

import java.util.ArrayList;
import java.util.List;

public class FormatSheet extends BottomSheetDialogFragment {

    private static final String ARG_URL = "url";

    public static FormatSheet newInstance(String url) {
        FormatSheet f = new FormatSheet();
        Bundle b = new Bundle();
        b.putString(ARG_URL, url);
        f.setArguments(b);
        return f;
    }

    public static class Option {
        public final String label;
        public final String size;
        public final boolean audioOnly;
        public final String ytArgs;
        public final String tag;
        public final String note;
        public Option(String label, String size, boolean audioOnly,
                      String ytArgs, String tag, String note) {
            this.label = label; this.size = size;
            this.audioOnly = audioOnly;
            this.ytArgs = ytArgs; this.tag = tag; this.note = note;
        }
    }

    private final List<Option> options = new ArrayList<>();
    private RadioGroup musicGroup, videoGroup;
    private RadioButton checkedRadio;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.sheet_format, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        String url = getArguments() != null ? getArguments().getString(ARG_URL) : null;

        TextView cancel = view.findViewById(R.id.btnCancel);
        TextView download = view.findViewById(R.id.btnDownload);
        musicGroup = view.findViewById(R.id.musicGroup);
        videoGroup = view.findViewById(R.id.videoGroup);

        addDefaultOptions();
        render();

        cancel.setOnClickListener(v -> dismiss());
        download.setOnClickListener(v -> {
            Option opt = currentSelection();
            if (opt == null) return;
            Context ctx = requireContext();
            DownloadService.start(ctx, url, opt);
            dismiss();
        });
    }

    private void addDefaultOptions() {
        // MP3 options
        options.clear();
        options.add(new Option("Fast (MP3)", "approx", true,
                "-x --audio-format mp3 -aq 2", "audio_fast", null));
        options.add(new Option("Classic MP3 70K", "70K", true,
                "-x --audio-format mp3 -aq 1", "audio_low", "Low"));
        options.add(new Option("Classic MP3 128K", "128K", true,
                "-x --audio-format mp3 -aq 5", "audio_med", null));
        options.add(new Option("Classic MP3 320K", "320K", true,
                "-x --audio-format mp3 -aq 0", "audio_high", "Slow"));
        // Video options
        options.add(new Option("Fast (144p)", "144p", false,
                "-f bv*[height<=144]+ba/b[height<=144] --merge-output-format mp4",
                "v144", "Low"));
        options.add(new Option("Fast (240p)", "240p", false,
                "-f bv*[height<=240]+ba/b[height<=240] --merge-output-format mp4",
                "v240", null));
        options.add(new Option("Fast (360p)", "360p", false,
                "-f bv*[height<=360]+ba/b[height<=360] --merge-output-format mp4",
                "v360", null));
        options.add(new Option("High quality (720p)", "720p", false,
                "-f bv*[height<=720]+ba/b[height<=720] --merge-output-format mp4",
                "v720", null));
        options.add(new Option("Full HD (1080p)", "1080p", false,
                "-f bv*[height<=1080]+ba/b[height<=1080] --merge-output-format mp4",
                "v1080", null));
    }

    private void render() {
        musicGroup.removeAllViews();
        videoGroup.removeAllViews();
        for (Option o : options) {
            RadioButton rb = new RadioButton(requireContext());
            rb.setText(o.label + (o.note != null ? "   [" + o.note + "]" : ""));
            rb.setTag(o);
            rb.setTextSize(15);
            rb.setPadding(8, 16, 8, 16);
            (o.audioOnly ? musicGroup : videoGroup).addView(rb);
        }
        // default selection: High quality 720p
        for (int i = 0; i < videoGroup.getChildCount(); i++) {
            RadioButton rb = (RadioButton) videoGroup.getChildAt(i);
            if ("v720".equals(((Option) rb.getTag()).tag)) {
                rb.setChecked(true);
                checkedRadio = rb;
                break;
            }
        }
        RadioGroup.OnCheckedChangeListener l = (g, id) -> checkedRadio = (RadioButton) g.findViewById(id);
        musicGroup.setOnCheckedChangeListener(l);
        videoGroup.setOnCheckedChangeListener(l);
    }

    private Option currentSelection() {
        if (checkedRadio == null) return null;
        return (Option) checkedRadio.getTag();
    }
}
