package com.vidgrab.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import com.vidgrab.app.download.DownloadService;
import com.vidgrab.app.format.FormatSheet;
import com.vidgrab.app.fragment.LibraryFragment;
import com.vidgrab.app.fragment.MusicFragment;
import com.vidgrab.app.fragment.SearchFragment;
import com.vidgrab.app.player.Mp3PlayerActivity;
import com.vidgrab.app.player.VideoPlayerActivity;
import com.vidgrab.app.settings.SettingsActivity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private static final Pattern URL = Pattern.compile(
            "(?:https?://)?(?:www\\.)?(?:youtube\\.com/.*v=|youtu\\.be/|youtube\\.com/shorts/)[\\w-]+",
            Pattern.CASE_INSENSITIVE);

    private EditText input;
    private TextView tabSearch, tabYouTube, tabMusic, tabMore;
    private ImageView navSearch, navPlay, navSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        input = findViewById(R.id.searchInput);
        tabSearch = findViewById(R.id.tabSearch);
        tabYouTube = findViewById(R.id.tabYouTube);
        tabMusic = findViewById(R.id.tabMusic);
        tabMore = findViewById(R.id.tabMore);

        navSearch = findViewById(R.id.navSearch);
        navPlay = findViewById(R.id.navPlay);
        navSettings = findViewById(R.id.navSettings);

        findViewById(R.id.searchButton).setOnClickListener(v -> handleSearch());
        findViewById(R.id.appLogo).setOnClickListener(v -> handleSearch());

        // Tabs
        View.OnClickListener tabClick = v -> {
            int id = v.getId();
            if (id == R.id.tabSearch || id == R.id.navSearch) showTab(0);
            else if (id == R.id.tabYouTube) showTab(1);
            else if (id == R.id.tabMusic || id == R.id.navPlay) {
                startActivity(new Intent(this, Mp3PlayerActivity.class));
            }
            else if (id == R.id.tabMore || id == R.id.navSettings) {
                startActivity(new Intent(this, SettingsActivity.class));
            }
        };
        tabSearch.setOnClickListener(tabClick);
        tabYouTube.setOnClickListener(tabClick);
        tabMusic.setOnClickListener(tabClick);
        tabMore.setOnClickListener(tabClick);
        navSearch.setOnClickListener(tabClick);
        navPlay.setOnClickListener(tabClick);
        navSettings.setOnClickListener(tabClick);

        highlightTab(0);
        showFragment(new LibraryFragment());

        // Handle share from YouTube / other apps
        handleShareIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShareIntent(intent);
    }

    private void handleShareIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (TextUtils.isEmpty(text)) return;
        Matcher m = URL.matcher(text);
        if (m.find()) {
            String videoUrl = m.group();
            input.setText(videoUrl);
            openFormatSheet(videoUrl);
        }
    }

    private void handleSearch() {
        String q = input.getText().toString().trim();
        if (TextUtils.isEmpty(q)) {
            Toast.makeText(this, "URL ya search term daaliye", Toast.LENGTH_SHORT).show();
            return;
        }
        Matcher m = URL.matcher(q);
        if (m.find()) {
            openFormatSheet(m.group());
        } else {
            // text search — let SearchFragment handle it (YouTube search via web)
            SearchFragment f = new SearchFragment();
            Bundle b = new Bundle();
            b.putString("query", q);
            f.setArguments(b);
            showFragment(f);
        }
    }

    private void openFormatSheet(String url) {
        FormatSheet sheet = FormatSheet.newInstance(url);
        sheet.show(getSupportFragmentManager(), "FormatSheet");
    }

    private void showTab(int idx) {
        highlightTab(idx);
        if (idx == 0) showFragment(new LibraryFragment());
        else if (idx == 1) showFragment(new com.vidgrab.app.fragment.YouTubeFragment());
    }

    private void highlightTab(int idx) {
        int active = getResources().getColor(R.color.yellow, getTheme());
        int inactive = getResources().getColor(R.color.text_secondary, getTheme());
        tabSearch.setTextColor(idx == 0 ? active : inactive);
        tabYouTube.setTextColor(idx == 1 ? active : inactive);
    }

    private void showFragment(Fragment f) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.contentFrame, f)
                .commit();
    }
}
