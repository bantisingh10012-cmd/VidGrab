package com.vidgrab.app.download;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.provider.MediaStore;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import com.yausername.youtubedl_android.YoutubeDL;
import com.yausername.youtubedl_android.YoutubeDLException;
import com.yausername.youtubedl_android.YoutubeDLRequest;
import com.vidgrab.app.MainActivity;
import com.vidgrab.app.R;

import java.io.File;
import java.util.UUID;

public class DownloadService extends Service {

    private static final String CH_ID = "vidgrab_downloads";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_OPT_LABEL = "label";
    public static final String EXTRA_OPT_AUDIO = "audio_only";
    public static final String EXTRA_OPT_ARGS = "args";

    public static void start(Context ctx, String url,
                             com.vidgrab.app.format.FormatSheet.Option opt) {
        Intent i = new Intent(ctx, DownloadService.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_OPT_LABEL, opt.label);
        i.putExtra(EXTRA_OPT_AUDIO, opt.audioOnly);
        i.putExtra(EXTRA_OPT_ARGS, opt.ytArgs);
        ctx.startForegroundService(i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ensureChannel();
        Notification n = new NotificationCompat.Builder(this, CH_ID)
                .setContentTitle(getString(R.string.app_name))
                .setContentText("Download starting…")
                .setSmallIcon(R.drawable.ic_download)
                .setOngoing(true)
                .build();
        startForeground(1, n);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(@Nullable Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String url = intent.getStringExtra(EXTRA_URL);
        String label = intent.getStringExtra(EXTRA_OPT_LABEL);
        boolean audioOnly = intent.getBooleanExtra(EXTRA_OPT_AUDIO, false);
        String args = intent.getStringExtra(EXTRA_OPT_ARGS);
        runDownload(url, label, audioOnly, args);
        return START_NOT_STICKY;
    }

    private void runDownload(String url, String label, boolean audioOnly, String args) {
        try {
            YoutubeDL.getInstance().init(getApplication());
            File dir = new File(
                    Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_DOWNLOADS), "VidGrab");
            if (!dir.exists()) dir.mkdirs();
            String out = "%(title)s.%(ext)s";
            YoutubeDLRequest req = new YoutubeDLRequest(url);
            req.addOption("-o", new File(dir, out).getAbsolutePath());
            if (args != null && !args.isEmpty()) {
                for (String part : args.split("\\s+(?=-)")) {
                    if (part.trim().isEmpty()) continue;
                    req.addOption(part.trim(), null);
                }
            }
            final int[] progressRef = {-1};

            YoutubeDL.getInstance().execute(req, UUID.randomUUID().toString(),
                    (progress, etaInSeconds) -> {
                        if ((int) progress != progressRef[0]) {
                            progressRef[0] = (int) progress;
                            updateProgress((int) progress, label);
                        }
                    });

            // On Android 10+, also expose in MediaStore so Files apps see it
            indexDownloads(dir);
            postDone(label);
        } catch (YoutubeDLException e) {
            postError(label, e.getMessage());
        }
    }

    private void indexDownloads(File dir) {
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File f : files) {
            if (f.isDirectory()) continue;
            ContentValues v = new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME, f.getName());
            v.put(MediaStore.Downloads.MIME_TYPE,
                    f.getName().endsWith(".mp3") ? "audio/mpeg" : "video/mp4");
            v.put(MediaStore.Downloads.RELATIVE_PATH,
                    Environment.DIRECTORY_DOWNLOADS + "/VidGrab");
            v.put(MediaStore.Downloads.IS_PENDING, 1);
            getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            v.clear();
            v.put(MediaStore.Downloads.IS_PENDING, 0);
        }
    }

    private void updateProgress(int pct, String label) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        Notification n = new NotificationCompat.Builder(this, CH_ID)
                .setContentTitle("Downloading " + label)
                .setContentText(pct + "%")
                .setSmallIcon(R.drawable.ic_download)
                .setProgress(100, pct, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
        nm.notify(1, n);
    }

    private void postDone(String label) {
        stopForeground(true);
        Notification n = new NotificationCompat.Builder(this, CH_ID)
                .setContentTitle("Download finished")
                .setContentText(label)
                .setSmallIcon(R.drawable.ic_download)
                .setAutoCancel(true)
                .setContentIntent(pendingMain())
                .build();
        getSystemService(NotificationManager.class).notify(2, n);
        stopSelf();
    }

    private void postError(String label, String msg) {
        stopForeground(true);
        Notification n = new NotificationCompat.Builder(this, CH_ID)
                .setContentTitle("Download failed")
                .setContentText(label + " — " + msg)
                .setSmallIcon(R.drawable.ic_download)
                .setAutoCancel(true)
                .setContentIntent(pendingMain())
                .build();
        getSystemService(NotificationManager.class).notify(3, n);
        stopSelf();
    }

    private PendingIntent pendingMain() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_IMMUTABLE);
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CH_ID, "Downloads", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }
}
