package com.vidgrab.app.download;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class HistoryDb extends SQLiteOpenHelper {

    private static final String DB = "vidgrab_history.db";
    private static final String T = "downloads";

    public static class Row {
        public long id;
        public String title;
        public String path;
        public String size;
        public long ts;
        public int downloadProgress;
    }

    public HistoryDb(@Nullable Context c) {
        super(c, DB, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + T + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "title TEXT, path TEXT, size TEXT, ts INTEGER, progress INTEGER)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int o, int n) {}

    public long add(String title, String path, String size) {
        ContentValues v = new ContentValues();
        v.put("title", title);
        v.put("path", path);
        v.put("size", size);
        v.put("ts", System.currentTimeMillis());
        v.put("progress", 0);
        return getWritableDatabase().insert(T, null, v);
    }

    public void setProgress(long id, int p) {
        ContentValues v = new ContentValues();
        v.put("progress", p);
        getWritableDatabase().update(T, v, "id=?", new String[]{String.valueOf(id)});
    }

    public void remove(long id) {
        getWritableDatabase().delete(T, "id=?", new String[]{String.valueOf(id)});
    }

    public List<Row> all() {
        Cursor c = getReadableDatabase().query(T, null, null, null, null, null,
                "ts DESC");
        List<Row> out = new ArrayList<>();
        while (c.moveToNext()) {
            Row r = new Row();
            r.id = c.getLong(c.getColumnIndexOrThrow("id"));
            r.title = c.getString(c.getColumnIndexOrThrow("title"));
            r.path = c.getString(c.getColumnIndexOrThrow("path"));
            r.size = c.getString(c.getColumnIndexOrThrow("size"));
            r.ts = c.getLong(c.getColumnIndexOrThrow("ts"));
            r.downloadProgress = c.getInt(c.getColumnIndexOrThrow("progress"));
            out.add(r);
        }
        c.close();
        return out;
    }
}
