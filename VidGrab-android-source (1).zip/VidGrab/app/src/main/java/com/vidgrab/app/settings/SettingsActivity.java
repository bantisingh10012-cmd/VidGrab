package com.vidgrab.app.settings;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.vidgrab.app.R;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        findViewById(R.id.backButton).setOnClickListener(v -> finish());

        for (Object tag : new Object[] {
                R.id.rowDownloadSettings, R.id.rowNotification,
                R.id.rowTheme, R.id.rowRecovery, R.id.rowStatus,
                R.id.rowVault, R.id.rowJunk, R.id.rowBoost,
                R.id.rowBattery, R.id.rowLarge }) {
            View row = findViewById((int) tag);
            row.setOnClickListener(v -> {
                ((TextView) row.findViewById(R.id.rowTitle));
            });
        }
    }
}
