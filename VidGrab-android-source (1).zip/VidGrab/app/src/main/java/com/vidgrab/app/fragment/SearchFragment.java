package com.vidgrab.app.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.vidgrab.app.R;

public class SearchFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater i,
                             @Nullable ViewGroup c,
                             @Nullable Bundle b) {
        WebView wv = new WebView(requireContext());
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        String q = getArguments() != null ? getArguments().getString("query") : null;
        if (q == null || q.isEmpty()) q = "trending YouTube videos";
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl("https://m.youtube.com/results?search_query=" + q.replace(" ", "+"));
        return wv;
    }
}
