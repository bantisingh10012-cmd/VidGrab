package com.vidgrab.app.adapter;

import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.vidgrab.app.R;
import com.vidgrab.app.download.HistoryDb;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DownloadAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface Click {
        void onClick(HistoryDb.Row row);
    }

    private final List<HistoryDb.Row> data = new ArrayList<>();
    private final Click click;

    public DownloadAdapter(List<HistoryDb.Row> rows, Click click) {
        this.click = click;
        replace(rows);
    }

    public void replace(List<HistoryDb.Row> rows) {
        data.clear();
        if (rows != null) data.addAll(rows);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return data.get(position).downloadProgress < 100 ? 0 : 1;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (type == 0) {
            return new ProgressHolder(inf.inflate(R.layout.row_downloading, parent, false));
        }
        return new DoneHolder(inf.inflate(R.layout.row_downloaded, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
        HistoryDb.Row row = data.get(pos);
        if (holder instanceof ProgressHolder) {
            ((ProgressHolder) holder).bind(row, click);
        } else {
            ((DoneHolder) holder).bind(row, click);
        }
    }

    @Override
    public int getItemCount() { return data.size(); }

    static class ProgressHolder extends RecyclerView.ViewHolder {
        TextView title, status;
        ProgressBar bar;
        ImageView thumb;
        ProgressHolder(View v) {
            super(v);
            title = v.findViewById(R.id.title);
            status = v.findViewById(R.id.status);
            bar = v.findViewById(R.id.progress);
            thumb = v.findViewById(R.id.thumb);
        }

        void bind(HistoryDb.Row r, Click c) {
            title.setText(r.title != null ? r.title : "Unconfirmed_download");
            status.setText(r.downloadProgress < 1 ? "Login required"
                    : String.format(Locale.US, "%.1f%%   ETA", r.downloadProgress));
            bar.setProgress(r.downloadProgress);
            itemView.setOnClickListener(v -> c.onClick(r));
        }
    }

    static class DoneHolder extends RecyclerView.ViewHolder {
        TextView title, meta;
        ImageView thumb, menu;
        DoneHolder(View v) {
            super(v);
            title = v.findViewById(R.id.title);
            meta = v.findViewById(R.id.meta);
            thumb = v.findViewById(R.id.thumb);
            menu = v.findViewById(R.id.menu);
        }
        void bind(HistoryDb.Row r, Click c) {
            title.setText(r.title != null ? r.title : "(untitled)");
            String age = DateUtils.getRelativeTimeSpanString(r.ts).toString();
            meta.setText(age + "  •  " + r.size);
            itemView.setOnClickListener(v -> c.onClick(r));
            menu.setOnClickListener(v -> {});
        }
    }
}
