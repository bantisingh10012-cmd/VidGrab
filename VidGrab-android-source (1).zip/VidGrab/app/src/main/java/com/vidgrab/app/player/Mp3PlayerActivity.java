package com.vidgrab.app.player;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.vidgrab.app.R;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Mp3PlayerActivity extends AppCompatActivity {

    private MediaPlayer mp;
    private List<File> tracks = new ArrayList<>();
    private ListView list;
    private TextView nowPlaying;
    private SeekBar seek;
    private ImageButton playPause;
    private int currentIndex = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_mp3_player);

        list = findViewById(R.id.trackList);
        nowPlaying = findViewById(R.id.nowPlaying);
        seek = findViewById(R.id.seekBar);
        playPause = findViewById(R.id.btnPlayPause);
        ImageButton prev = findViewById(R.id.btnPrev);
        ImageButton next = findViewById(R.id.btnNext);

        loadTracks();
        list.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, names()));
        list.setOnItemClickListener((AdapterView<?> p, View v, int pos, long id) ->
                playAt(pos));

        playPause.setOnClickListener(v -> {
            if (mp == null) return;
            if (mp.isPlaying()) {
                mp.pause();
                playPause.setImageResource(R.drawable.ic_play);
            } else {
                mp.start();
                playPause.setImageResource(R.drawable.ic_pause);
            }
        });
        prev.setOnClickListener(v -> {
            if (currentIndex > 0) playAt(currentIndex - 1);
        });
        next.setOnClickListener(v -> {
            if (currentIndex < tracks.size() - 1) playAt(currentIndex + 1);
        });
    }

    private void loadTracks() {
        File dir = new File(
                Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS), "VidGrab");
        if (dir.isDirectory()) {
            File[] files = dir.listFiles((f) ->
                    f.isFile() && f.getName().toLowerCase().endsWith(".mp3"));
            if (files != null) {
                for (File f : files) tracks.add(f);
            }
        }
    }

    private List<String> names() {
        List<String> n = new ArrayList<>();
        for (File f : tracks) n.add(f.getName());
        return n;
    }

    private void playAt(int idx) {
        if (idx < 0 || idx >= tracks.size()) return;
        currentIndex = idx;
        File f = tracks.get(idx);
        nowPlaying.setText(f.getName());
        try {
            if (mp != null) mp.release();
            mp = new MediaPlayer();
            mp.setDataSource(f.getAbsolutePath());
            mp.setOnCompletionListener(mediaPlayer -> {
                if (currentIndex < tracks.size() - 1) playAt(currentIndex + 1);
            });
            mp.prepare();
            mp.start();
            playPause.setImageResource(R.drawable.ic_pause);
            seek.setMax(mp.getDuration());
        } catch (Exception e) {
            nowPlaying.setText("Error: " + e.getMessage());
        }
    }

    @Override
    protected void onPause() { super.onPause(); if (mp != null) mp.pause(); }

    @Override
    protected void onDestroy() { super.onDestroy(); if (mp != null) mp.release(); }
}
