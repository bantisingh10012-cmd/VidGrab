package com.vidgrab.app.player;

import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.vidgrab.app.R;

import java.io.File;

public class VideoPlayerActivity extends AppCompatActivity {

    private ExoPlayer player;
    private TextView titleView;
    private ImageButton fabClose;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_video_player);

        PlayerView view = findViewById(R.id.playerView);
        titleView = findViewById(R.id.playerTitle);
        fabClose = findViewById(R.id.playerClose);

        Uri uri = getIntent().getData();
        String title = new File(uri.getPath()).getName();
        titleView.setText(title);
        fabClose.setOnClickListener(v -> finish());

        player = new ExoPlayer.Builder(this).build();
        view.setPlayer(player);
        if (uri != null) {
            player.setMediaItem(MediaItem.fromUri(uri));
            player.prepare();
            player.play();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) player.release();
    }
}
