package com.vidgrab.app.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.vidgrab.app.R;
import com.vidgrab.app.adapter.DownloadAdapter;
import com.vidgrab.app.download.HistoryDb;
import com.vidgrab.app.player.Mp3PlayerActivity;
import com.vidgrab.app.player.VideoPlayerActivity;

import java.io.File;
import java.util.List;

public class LibraryFragment extends Fragment {

    private RecyclerView list;
    private DownloadAdapter adapter;
    private TextView downloadingCount, downloadedCount;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle b) {
        return inflater.inflate(R.layout.fragment_library, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        list = v.findViewById(R.id.downloadList);
        downloadingCount = v.findViewById(R.id.downloadingCount);
        downloadedCount = v.findViewById(R.id.downloadedCount);

        ImageView filter = v.findViewById(R.id.actionFilter);
        ImageView trash  = v.findViewById(R.id.actionTrash);
        ImageView search = v.findViewById(R.id.actionSearch);

        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        refresh();

        search.setOnClickListener(x -> {});
        filter.setOnClickListener(x -> {});
        trash.setOnClickListener(x -> {
            new HistoryDb(requireContext()).getWritableDatabase().delete(
                    "downloads", null, null);
            refresh();
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        List<HistoryDb.Row> rows = new HistoryDb(requireContext()).all();
        if (adapter == null) {
            adapter = new DownloadAdapter(rows, this::openItem);
            list.setAdapter(adapter);
        } else {
            adapter.replace(rows);
        }
        long downloading = rows.stream().filter(r -> r.downloadProgress < 100).count();
        long downloaded = rows.size() - downloading;
        downloadingCount.setText("Downloading (" + downloading + ")");
        downloadedCount.setText("Downloaded (" + downloaded + ")");
    }

    private void openItem(HistoryDb.Row r) {
        File f = new File(r.path);
        if (!f.exists()) return;
        Intent i;
        if (r.path.toLowerCase().endsWith(".mp3")) {
            i = new Intent(requireContext(), Mp3PlayerActivity.class);
        } else {
            i = new Intent(requireContext(), VideoPlayerActivity.class);
        }
        i.setData(Uri.fromFile(f));
        startActivity(i);
    }
}
